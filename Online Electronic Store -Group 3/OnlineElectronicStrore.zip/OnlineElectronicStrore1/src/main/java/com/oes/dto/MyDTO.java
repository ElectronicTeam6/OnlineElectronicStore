package com.oes.dto;

public interface MyDTO {

}
